package atests;

import java.net.URL;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.Assert;
import org.testng.annotations.Test;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.TouchAction;

public class appinstalled {
	
	static AppiumDriver<MobileElement> driver;

	public static void main(String[] args) {
		
		try {
			openApp();
		} catch (Exception e) {
			System.out.println(e.getCause());
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
	}
	
	public static void openApp() throws Exception {
		
		DesiredCapabilities cap = new DesiredCapabilities();
		
		cap.setCapability("deviceName", "RealMe XT");
		cap.setCapability("udid", "654654fg");
		cap.setCapability("platformNam", "Android");
		cap.setCapability("platformVersiom", "10");
		cap.setCapability("appPackage", "com.myos.777Games2");
		cap.setCapability("appActivity", "com.myos.777Games2.777Games");
		cap.setCapability("appActivity:","SplashScreenActivity");
		URL url = new URL ("http://127.0.0.1:4723/wd/hub");
		
		driver = new AppiumDriver<MobileElement>(url, cap);
		System.out.println("Application Started .....");
		seekBarTest();
		
		MobileElement signup = driver.findElement(By.id("com.myos.777Games2:id/signup"));
		signup.click();
		
		MobileElement mob_num = driver.findElement(By.className("com.myos.777Games2:id/mob_num"));
		mob_num.sendKeys("9867933453");
		
		MobileElement refferal = driver.findElement(By.className("com.myos.777Games2:id/refferal"));
		refferal.click();
		String expectedMessage = "Number alread Exists";
		String actualMessage = refferal.getText();
		Assert.assertTrue(actualMessage.contains(expectedMessage),"Number not Present .. Redirecting to Login Page");
		
		MobileElement login = driver.findElement(By.className("com.myos.777Games2:id/login"));
		login.click();
		
		MobileElement mob_num2 = driver.findElement(By.className("com.myos.777Games2:id/mob_num2"));
		mob_num2.sendKeys("9867933453");
		
		MobileElement login2 = driver.findElement(By.className("com.myos.777Games2:id/login2"));
		login2.click();
		
		MobileElement otp = driver.findElement(By.className("com.myos.777Games2:id/otp"));
		otp.click();
		String expectedMessage2 = "Incorrect OTP";
		String actualMessage2 = otp.getText();
		Assert.assertTrue(actualMessage2.contains(expectedMessage2),"Number not Present .. Redirecting to Login Page");

		System.out.println("Completed .....");
		
		driver.quit();
	}
	
	
	private static void seekBarTest() {
		// TODO Auto-generated method stub
		
	}
	@Test
	public void SeekBarTest(){
	MobileElement slider = driver.findElement(By.id("com.myos.777Games2:id/slider"));
	int xAxisStartPoint = slider.getLocation().getX();
	int xAxisEndPoint = xAxisStartPoint + slider.getSize().getWidth();
	int yAxis = slider.getLocation().getY();
	TouchAction act=new TouchAction(driver);
	//pressed x axis & y axis of seekbar and move seekbar till the end
	act.press(xAxisStartPoint,yAxis).moveTo(xAxisEndPoint-1,yAxis).release().perform();
	}

}
